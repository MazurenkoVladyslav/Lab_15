function convertToCamelCase(cssStyle) {
    const parts = cssStyle.split('-');
    let camelCaseStyle = parts[0];
    for (let i = 1; i < parts.length; i++) {
        const part = parts[i];
        const capitalizedPart = part.charAt(0).toUpperCase() + part.slice(1);
        camelCaseStyle += capitalizedPart;
    }
    return camelCaseStyle;
}

const styles = ['font-size', 'background-color', 'text-align'];
const outputDiv = document.getElementById('output');
styles.forEach(style => {
    const camelCaseStyle = convertToCamelCase(style);
    outputDiv.innerHTML += `<p>${style} => ${camelCaseStyle}</p>`;
});
